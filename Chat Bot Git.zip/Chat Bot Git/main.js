let chats_div = document.querySelector('.chats');
let option1 = ['India', 'Russia', 'USA', 'Japan'];

// Sub-options for CRN selection
let crnSuboptions = [
    { text: 'Book a slot' },
    { text: 'other query' }
];

let option1_suboptions = [
    {
        text: 'Select your course',
        options: [
            { text: 'web development', options: crnSuboptions },
            { text: 'data analyst', options: crnSuboptions },
            { text: 'digital marketing', options: crnSuboptions },
            { text: 'data analyst', options: crnSuboptions }
        ]
    },
    {
        text: 'Have a Query',
        options: [
            { text: 'Call with us', options: crnSuboptions },
            { text: 'Chat with us', options: crnSuboptions }
        ]
    }
];

function create_div() {
    // Disable the button after it's clicked
    document.querySelector('button').disabled = true;
    displayChatbotMessage("chatbot...");
    var div = document.createElement('div');
    div.innerHTML = "<h1>Hello, I am your Assistant. Please select a country</h1>";
    // div.style.background = "red";
    div.classList.add('first_chat');
    chats_div.append(div);
    // document.querySelector('.main_child').style.display = "none";
    setTimeout(function () {
        addOptions(option1);
    }, 1000);
    scrollChatsToBottom();
}

function addOptions(options) {
    displayChatbotMessage("chatbot...");
    var optionsDiv = document.createElement('div');
    optionsDiv.classList.add('option_country_div')
    options.forEach(function (option, index) {
        var button = document.createElement('button');
        button.classList.add('option_country')
        button.innerHTML = `<h3>${option}</h3>`;
        button.onclick = function () {
            setTimeout(function () {
                // addOptions(option1);
                handleOptionClick(index);
            }, 1000);
        };
        optionsDiv.appendChild(button);
    });
    chats_div.appendChild(optionsDiv);
    scrollChatsToBottom();
}

function addSuboptions(suboptions) {
    displayChatbotMessage("chatbot...");
    var suboptionsDiv = document.createElement('div');
    suboptionsDiv.classList.add('suboptions_div');
    suboptions.forEach(function (suboption, index) {
        var button = document.createElement('button');
        button.classList.add('suboption');
        button.innerHTML = `<h3>${suboption.text}</h3>`;
        button.onclick = function () {
            if (suboption.options) {
                setTimeout(function () {
                    addSuboptions(suboption.options);
                    // addOptions(option1);
                }, 1000);
            } else {
                setTimeout(function () {
                    handleSuboptionClick(suboption.text);
                    // addOptions(option1);
                }, 1000);
            }
        };
        suboptionsDiv.appendChild(button);
    });
    chats_div.appendChild(suboptionsDiv);
    scrollChatsToBottom();  
}
function scrollChatsToBottom() {
    chats_div.scrollTop = chats_div.scrollHeight;
}

function handleOptionClick(index) {
    // chats_div.innerHTML = "";
    // Handle the user's selection based on the index
    // displayChatbotMessage("chatbot");
    var response = option1[index];
    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = `<h1>${response}</h1>`;
    responseDiv.classList.add("response");
    var user = document.createElement('div');
    user.innerHTML = `<h1><i class="fa-solid fa-user fa-sm icon_user"></i>user</h1>`;
    user.classList.add("user_message");
    // responseDiv.style.background = "blue";
    chats_div.appendChild(user);
    chats_div.appendChild(responseDiv);


    // Check if sub-options exist for the selected option
    if (index === 0) {
        // For option 1 (India), add sub-options
        addSuboptions(option1_suboptions);
    }
    if (index === 1) {
        // For option 1 (India), add sub-options
        addSuboptions(option1_suboptions);
    }
    if (index === 2) {
        // For option 1 (India), add sub-options
        addSuboptions(option1_suboptions);
    }
    if (index === 3) {
        // For option 1 (India), add sub-options
        addSuboptions(option1_suboptions);
    }

    scrollChatsToBottom();
    // Add more cases for other options as needed
}

function handleSuboptionClick(answer) {
    let form=document.getElementsByClassName('form_input')[0];
    // Handle the user's sub-option selection
    var response = answer;
    // displayChatbotMes/sage("chatbot");
    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = `<h4>${response}</h4>`;
    responseDiv.classList.add("response_sub");
    var user = document.createElement('div');
    user.innerHTML = `<h1><i class="fa-solid fa-user fa-sm icon_user"></i>user</h1>`;
    user.classList.add("user_message_sub");
    // responseDiv.style.background = "green";
    chats_div.appendChild(user);
    chats_div.appendChild(responseDiv);

    // You can perform additional actions based on the sub-option selected
    if (answer === 'Book a slot') {

        // displayChatbotMessage("Fetching your account balance...");
        // Show input box for entering name
        var nameInput = document.createElement('input');
        nameInput.placeholder = 'Enter your name';
        nameInput.type = 'text';
        form.appendChild(nameInput);

        // Show button for submitting the name
        var submitButton = document.createElement('button');
        submitButton.innerHTML = '<i class="fa-solid fa-share icon"></i>';
        submitButton.classList.add('gen')
        submitButton.onclick = function () {
            handleAccountBalance(nameInput.value);
            nameInput.value = ""

        };
        nameInput.addEventListener('keydown', function (event) {
            if (event.key === "Enter") {
                handleAccountBalance(nameInput.value);
                nameInput.value = ""
            }
        });
        form.appendChild(submitButton);
    } else if (answer === 'other query') {
        // Show input box for entering new mobile number
        var mobileInput = document.createElement('input');
        mobileInput.placeholder = 'Enter your query';
        mobileInput.type = 'text';
        form.appendChild(mobileInput);

        // Show button for submitting the new number
        var submitButton = document.createElement('button');
        submitButton.innerHTML = '<i class="fa-solid fa-share icon"></i>';
        submitButton.classList.add('gen')
        submitButton.onclick = function () {
            handleMobileSubmit(mobileInput.value);
            mobileInput.value = ""
        };
        mobileInput.addEventListener('keydown', function (event) {
            if (event.key === "Enter") {
                handleMobileSubmit(mobileInput.value);
                mobileInput.value = ""
            }
        });
        form.appendChild(submitButton);
    }
    else if (answer === 'Edit your name as PAN') {
        // Show input box for entering new mobile number
        var mobileInput = document.createElement('input');
        mobileInput.placeholder = 'Enter your name and contact number';
        mobileInput.type = 'text';
        form.appendChild(mobileInput);

        // Show button for submitting the new number
        var submitButton = document.createElement('button');
        submitButton.innerHTML = '<i class="fa-solid fa-share icon"></i>';
        submitButton.classList.add('gen')
        submitButton.onclick = function () {
            handleNameSubmit(mobileInput.value);
            mobileInput.value = ""
        };
        mobileInput.addEventListener('keydown', function (event) {
            if (event.key === "Enter") {
                handleNameSubmit(mobileInput.value);
                // handleMobileSubmit(mobileInput.value);
                mobileInput.value = ""
            }
        });
        form.appendChild(submitButton);
    }
    scrollChatsToBottom();
}

function handleNameSubmit(name) {
    // Handle the submitted name
    displayChatbotMessage("chatbot");
    var response = "<h3>Your slot has been booked</h3>";

    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = response;
    // responseDiv.style.background = "purple";
    responseDiv.classList.add("user_detail")
    chats_div.appendChild(responseDiv);
    scrollChatsToBottom();
}
function handleAccountBalance(name) {
    displayChatbotMessage("chatbot");
    // Handle the submitted name
    var response = "<h3>Our team will contact your soon your slot has been booked</h3>"+ name;

    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = response;
    responseDiv.classList.add("user_detail")
    // responseDiv.style.background = "purple";
    chats_div.appendChild(responseDiv);
    scrollChatsToBottom();
}

function handleMobileSubmit(mobile) {
    displayChatbotMessage("chatbot");
    // Handle the submitted mobile number
    var response = "<h3>Your query has been booked</h3>";

    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = response;
    responseDiv.classList.add("user_detail")
    // responseDiv.style.background = "orange";
    chats_div.appendChild(responseDiv);
    scrollChatsToBottom();
}

function handleNameSubmit(mobileInput) {
    displayChatbotMessage("chatbot");
    // Handle the submitted mobile number
    var response = "<h3>Your name updated successfully to: " + mobileInput;

    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = response;
    responseDiv.classList.add("user_detail");
    chats_div.appendChild(responseDiv);
    scrollChatsToBottom();
}

// Initial call to create_div function


let chatInitialized = false;  // Variable to track if chat is initialized

// function show() {
//     let form = document.getElementById('show');
//     let closeIcon = document.getElementById('closeIcon');
//     let botImage = document.querySelector('.heading img');

//     if (!chatInitialized) {
//         // If chat is not initialized, display it
//         form.style.display = 'block';
//         botImage.style.display = 'none'; // Hide the image
//         closeIcon.style.display = 'inline-block'; // Show the close icon
//         create_div();
//         chatInitialized = true;  // Set chat as initialized
//     } else {
//         // If chat is already initialized and just closed, clear previous chat and display it again
//         clearChat();
//         form.style.display = 'block';
//         botImage.style.display = 'none';
//         closeIcon.style.display = 'inline-block';
//     }
// }

function hide() {
    let form = document.getElementById('show');
    let closeIcon = document.getElementById('closeIcon');
    let botImage = document.querySelector('.heading img');

    form.style.display = 'none';
    botImage.style.display = 'inline-block'; // Show the image
    closeIcon.style.display = 'none'; // Hide the close icon
}

function clearChat() {
    chats_div.innerHTML = '';  // Clear chat content
}
// create_div();  // Start a new chat

function displayChatbotMessage(message) {
    var responseDiv = document.createElement('div');
    responseDiv.innerHTML = `<img src="./images/DSjjJVtWgP_jxGWP.png" class ="chat_bot_image"alt="Chatbot Image" class="chatbot-image">`; // Replace 'path_to_your_image.jpg' with your image path
    responseDiv.innerHTML += `<h1>${message}</h1>`;
    responseDiv.classList.add("response_chatbot");
    chats_div.appendChild(responseDiv);
    
}
document.querySelector('.image_icon').addEventListener('click', function() {
    let chatbox = document.querySelector('.main_child');
    let imageIcon = document.querySelector('.image_icon');
    let crossIcon = document.querySelector('.close-icon');
    create_div()
    // Toggle chatbox visibility
    if (chatbox.style.display === 'none') {
        chatbox.style.display = 'block';
        imageIcon.style.display = 'none';
        crossIcon.style.display = 'block';
        clearChat();  // Clear previous chat or any other necessary actions
    } else {
        chatbox.style.display = 'none';
        imageIcon.style.display = 'block';
        crossIcon.style.display = 'none';
    }
});

document.querySelector('.close-icon').addEventListener('click', function() {
    let chatbox = document.querySelector('.main_child');
    let imageIcon = document.querySelector('.image_icon');
    let crossIcon = document.querySelector('.close-icon');
    
    chatbox.style.display = 'none';
    imageIcon.style.display = 'block';
    crossIcon.style.display = 'none';
});
